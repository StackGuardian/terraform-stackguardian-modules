"""
mypy-boto3 module entrypoint.

Copyright 2025 Vlad Emelianov
"""

from mypy_boto3.main import main

main()
